"use strict";

exports.hello = function() {
    console.log( "hello, world !" );
};
